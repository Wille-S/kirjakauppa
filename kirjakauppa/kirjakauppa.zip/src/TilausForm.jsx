/* eslint-disable react/prop-types */
import { useState, useEffect } from "react";

// eslint-disable-next-line react/prop-types
function TilausForm({ onPeruuta, onLaheta, tilaus }) {
  const [formData, setFormData] = useState({
    etunimi: "",
    sukunimi: "",
    katuosoite: "",
    postitoimipaikka: "",
    paivays: new Date().toLocaleDateString(),
    tilausyhteenveto: "",
  });
  console.log(tilaus)
  useEffect(() => {
    const tilausyhteenveto = tilaus.map(
      (tilauskirja) =>
        `${tilauskirja.nimi}: ${tilauskirja.maara} kpl, ${
          tilauskirja.maara * tilauskirja.hinta
        } €`
    );

    setFormData((prevFormData) => ({ ...prevFormData, tilausyhteenveto }));
  }, [tilaus]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onLaheta(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="formi">
 <label>
  Tilausyhteenveto:
  <div>
    {formData.tilausyhteenveto && formData.tilausyhteenveto.length > 0 && formData.tilausyhteenveto.map((summary, index) => (
      <div key={index}>{summary}</div>
    ))}
  </div>
</label>
      <label>
        Päiväys:
        <span name="paivays">{formData.paivays}</span>
      </label>
      <label>
        <input
          type="text"
          name="etunimi"
          placeholder="Etunimi"
          value={formData.etunimi}
          onChange={handleInputChange}
        />
      </label>
      <label>
        <input
          type="text"
          name="sukunimi"
          placeholder="Sukunimi"
          value={formData.sukunimi}
          onChange={handleInputChange}
        />
      </label>
      <label>
        <input
          type="text"
          name="katuosoite"
          placeholder="Katuosoite"
          value={formData.katuosoite}
          onChange={handleInputChange}
        />
      </label>
      <label>
        <input
          type="text"
          name="postitoimipaikka"
          placeholder="Postitoimipaikka"
          value={formData.postitoimipaikka}
          onChange={handleInputChange}
        />
      </label>
      <button type="button" onClick={onPeruuta}>
        Peruuta
      </button>
      <button type="submit">Lähetä</button>
    </form>
  );
}

export default TilausForm;
