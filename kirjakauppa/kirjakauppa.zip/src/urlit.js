const kaikkiUrl = 'http://localhost:3008/kirjat';
const lisaysUrlPost = 'http://localhost:4009/rest/tilaukset';


export {kaikkiUrl, lisaysUrlPost}